Path-And-Address Changelog
==========================


Version 2.0.1 (2016-07-20)
--------------------------

- Allow port 0 (random port)


Version 1.1.0 (2016-04-02)
--------------------------

- Python 3 support ([#2](https://github.com/joeyespo/path-and-address/pull/2) - thanks, [@myhro][]!)
- Pytest support
- Cleanup


Version 1.0.0 (2014-08-02)
--------------------------

- Allow ':<port>' pattern


Version 0.2.0 (2013-01-05)
--------------------------

- Re-arranged project
- Added initial tests
- Bugfix: Allow integer port addresses in valid_address
- Bugfix: Allow integer port addresses in split_address


Version 0.1 (2012-12-08)
------------------------

First functional release.


[@myhro]: https://github.com/myhro
